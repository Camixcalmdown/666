
import os
import pandas as pd
import platform

def banner():
    print("""
    ██████╗  █████╗ ██╗   ██╗██████╗ ██╗     ██╗██████╗ 
    ██╔══██╗██╔══██╗██║   ██║██╔══██╗██║     ██║██╔══██╗
    ██████╔╝███████║██║   ██║██████╔╝██║     ██║██████╔╝
    ██╔═══╝ ██╔══██║██║   ██║██╔═══╝ ██║     ██║██╔═══╝ 
    ██║     ██║  ██║╚██████╔╝██║     ███████╗██║██║     
    ╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚══════╝╚═╝╚═╝     
    @ReaperSoft
    """)

def clear_console():
    os.system('cls' if platform.system() == 'Windows' else 'clear')

def get_directory_size(directory):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(directory):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

def format_size(size):
    if size < 1024 ** 2:  # меньше 1 МБ
        return f"{size} байт"
    elif size < 1024 ** 3:  # меньше 1 ГБ
        return f"{size / 1024 ** 2:.2f} МБ"
    else:  # 1 ГБ и больше
        return f"{size / 1024 ** 3:.2f} ГБ"

def search_in_file(file_path, keyword):
    try:
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path, encoding='utf-8', error_bad_lines=False)
            for index, row in df.iterrows():
                if keyword in row.to_string():
                    print(f"Found in {file_path}: {row.to_string()}")
        
        elif file_path.endswith('.xlsx') or file_path.endswith('.xls'):
            df = pd.read_excel(file_path, engine='openpyxl', error_bad_lines=False)
            for index, row in df.iterrows():
                if keyword in row.to_string():
                    print(f"Found in {file_path}: {row.to_string()}")
        
        elif file_path.endswith('.txt') or file_path.endswith('.sql'):
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    if keyword in line:
                        print(f"Found in {file_path}: {line.strip()}")
    
    except Exception as e:
        print(f"Error processing {file_path}: {e}")

def search_keyword_in_directory(directory, keyword):
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        if os.path.isfile(file_path):
            search_in_file(file_path, keyword)

def print_manuals():
    manuals = {
        "1": {
            "title": "OSINT разведка",
            "instructions": """\
1. Определите цель разведки (персона, организация, событие).
2. Соберите информацию из открытых источников:
   - Поиск в поисковых системах (Google, Bing).
   - Используйте социальные сети (Facebook, Twitter, LinkedIn) для поиска.
   - Изучите специализированные базы данных (например, WHOIS для доменов).
3. Проанализируйте собранную информацию:
   - Сравните данные из разных источников.
   - Определите возможные связи и зависимости.
4. Сохраните результаты в удобном формате (документ, таблица).
5. Обеспечьте конфиденциальность и безопасность собранной информации.
"""
        },
        "2": {
            "title": "Запуск .py скриптов на Termux",
            "instructions": """\
1. Установите Termux из Google Play или F-Droid.
2. Откройте Termux и обновите пакеты:
   ```
   pkg update && pkg upgrade
   ```
3. Установите Python:
   ```
   pkg install python
   ```
4. Перейдите в директорию, где находится ваш .py файл:
   ```
   cd /path/to/your/script
   ```
5. Запустите скрипт:
   ```
   python script.py
   ```
6. Если необходимо, установите дополнительные библиотеки:
   ```
   pip install library_name
   """
        },
        "3": {
            "title": "Запуск .py скриптов на Windows",
            "instructions": """\
1. Убедитесь, что Python установлен на вашем компьютере. Если нет, скачайте его с официального сайта.
2. Установите Python, следуя инструкциям установщика.
3. Откройте командную строку (cmd):
   - Нажмите Win + R, введите cmd и нажмите Enter.
4. Перейдите в директорию, где находится ваш .py файл:
   ```
   cd C:\path\to\your\script
   ```
5. Запустите скрипт:
   ```
   python script.py
   ```
6. Если необходимо, установите дополнительные библиотеки с помощью pip:
   ```
   pip install library_name
   """
        },
        "4": {
            "title": "Обучение распаковке zip и rar файлов на Android",
            "instructions": """\
1. Установите приложение для распаковки архивов, например, ZArchiver или RAR.
2. Откройте приложение и перейдите в папку с архивом.
3. Нажмите на архив (zip или rar).
4. Выберите опцию "Извлечь" или "Распаковать".
5. Укажите папку, куда нужно распаковать файлы, и подтвердите действие.
6. Дождитесь завершения процесса распаковки и проверьте файлы в указанной папке.
"""
        },
        "5": {
            "title": "Обучение кибербезопасности",
            "instructions": """\
1. Изучите основные понятия кибербезопасности:
   - Что такое киберугрозы.
   - Различие между вирусами, троянами и фишингом.
2. Ознакомьтесь с методами защиты:
   - Использование антивирусного ПО.
   - Установка брандмауэра.
3. Применяйте безопасные практики:
   - Используйте сложные пароли и двухфакторную аутентификацию.
   - Не открывайте подозрительные ссылки и вложения.
4. Регулярно обновляйте программное обеспечение и операционную систему.
5. Обучите сотрудников основам кибербезопасности, если вы работаете в компании.
"""
        },
        "6": {
            "title": "Как не попасть на Telegram фишинг",
            "instructions": """\
1. Никогда не переходите по подозрительным ссылкам, даже если они пришли от знакомых.
2. Проверяйте адреса отправителей на наличие ошибок и подозрительных символов.
3. Не сообщайте свои личные данные, пароли или коды подтверждения через сообщения.
4. Используйте двухфакторную аутентификацию для защиты аккаунта.
5. Если вы получили подозрительное сообщение, сообщите об этом в поддержку Telegram.
"""
        }
    }
    
    print("\n--- Мануалы ---")
    for key, manual in manuals.items():
        print(f"{key}. {manual['title']}")
    
    return manuals

def read_manual(manuals):
    choice = input("Выберите номер мануала для чтения: ").strip()
    if choice in manuals:
        print(f"\n{manuals[choice]['title']}:\n{manuals[choice]['instructions']}")
    else:
        print("Неверный выбор. Пожалуйста, выберите номер из списка.")

def main():
    while True:
        clear_console()
        banner()
        print("\nМеню:")
        
        # Показать размер папки с базами данных
        db_directory = 'bases'
        db_size = get_directory_size(db_directory)
        formatted_size = format_size(db_size)
        print(f"Размер папки с базами данных: {formatted_size}")

        print("1. Поиск в базах")
        print("2. Мануалы")
        print("3. Выход")
        choice = input("Выберите пункт меню (1-3): ").strip()
        
        if choice == '1':
            print("Введите ключевое слово для поиска:")
            keyword = input().strip()
            print("Поиск в папке 'bases'...")
            search_keyword_in_directory(db_directory, keyword)
            input("Нажмите Enter, чтобы продолжить...")
        elif choice == '2':
            manuals = print_manuals()
            read_manual(manuals)
            input("Нажмите Enter, чтобы продолжить...")
        elif choice == '3':
            print("Выход из программы.")
            break
        else:
            print("Неверный выбор. Пожалуйста, выберите 1, 2 или 3.")
            input("Нажмите Enter, чтобы продолжить...")

if __name__ == "__main__":
    main()
